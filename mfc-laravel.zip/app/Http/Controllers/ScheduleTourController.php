<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Session;

class ScheduleTourController extends Controller
{
    public function index(){
        if(Session::get('admin-user') || Session::get('user')){
           return view('schedule-tour');
        }
        else{
            return view('auth.login');
        }
    }

    public function chooseRoom(){
        return view('choose-room');
    }
}
